This is a datapack that is intended to be used to run the Minecraft Map "Duel: Insurgency". 

You are free to alter the map and datapack however you like, just so long as the map (or datapack) is re-uploaded without any notable changes. 
If you do upload a variation of either, I would politely ask for a link to the original be provided.

There is a text document named "Info.txt". The idea is to give a general rundown as to how the datapack is structured.
There is a lot and honestly, it is quite messy.
